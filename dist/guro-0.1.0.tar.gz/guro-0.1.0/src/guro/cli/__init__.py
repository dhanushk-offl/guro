# guro/cli/__init__.py
from .main import cli

__all__ = ['cli']